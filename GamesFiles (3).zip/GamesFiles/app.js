const express = require('express')
const bodyParser = require('body-parser')

const mysql = require('mysql2');

const usuarios = [{
    id: '1',
    nome: "Fernanda Alves",
    email: "fernanda@gmail.com",
    senha: "1234",
    apelido: "a"
    
}]

const app = express()

app.set('view engine', 'ejs')

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}))

const conexao = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'senai',
	database:'gamesfiles'
});

conexao.connect(function(erro){
	if(erro) throw erro;
	console.log('Conexão efetuada com sucesso!');
});


app.get("/", function (req, res) {
    res.render("home", {
    data: usuarios   
})
})

app.get("/json", (req, res) => {
    res.status(200).json(usuarios);
  });

app.get("/atualizar", function (req, res) {
    res.render("Atualizar", {
        data: usuarios
    })
})

app.get("/adicionar", function (req, res) {
    res.render("Adicionar", {
        data: usuarios
    })
})


app.post("/", (req, res) => {
    let id = req.body.id
    let nome = req.body.nome
    let email = req.body.email
    let senha = req.body.senha
    let apelido = req.body.apelido
    

    usuarios.push({
        id: id,
        nome: nome,
        email: email,
        senha: senha,
        apelido: apelido
        
    })


    // SQL
   let sql = `INSERT INTO usuarios (id, nome, email, senha, apelido) VALUES ('${id}', '${nome}', '${email}', '${senha}', '${apelido}')`;
        
   // Executar comando SQL
   conexao.query(sql, function(erro, retorno){
    // Caso ocorra algum erro
    if(erro) throw erro;
       console.log(retorno);



    res.render("home", {
        data: usuarios
    })
})
})

app.post('/delete', (req, res) => {
    var requestedid = req.body.id;
    var j = 0;
    usuarios.forEach(user => {
        j = j + 1;
        if (user.id === requestedid) {
            usuarios.splice((j - 1), 1)
        }
    })

    // SQL
   let sql = `DELETE FROM usuarios WHERE id = ${req.body.id}`;

   // Executar o comando SQL
   conexao.query(sql, function(erro, retorno){
   // Caso falhe o comando SQL
       if(erro) throw erro;

    res.render("home", {
        data: usuarios
    })
})
})
app.post('/update', (req, res) => {
    let id = req.body.id
    let nome = req.body.nome
    let email = req.body.email
    let senha = req.body.senha
    let apelido = req.body.apelido
    

    var j = 0;
    usuarios.forEach(user => {
        j = j + 1;
        if (user.id === id) {
            user.nome = nome
            user.email = email
            user.senha = senha
            user.apelido = apelido
        }
    })

    // SQL
    let sql = `UPDATE usuarios SET nome='${nome}', email='${email}', senha='${senha}', apelido='${apelido}' WHERE id=${req.body.id}`;
    
    // Executar comando SQL
    conexao.query(sql, function(erro, retorno){
    // Caso falhe o comando SQL
        if(erro) throw erro;


    res.render("home", {
        data: usuarios
    })
})
})
app.listen(3000, (req, res) => {
    console.log("Servidor rodando na porta 3000")
})